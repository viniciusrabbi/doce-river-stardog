package util;

public class WebMvcConfigurer {

}
